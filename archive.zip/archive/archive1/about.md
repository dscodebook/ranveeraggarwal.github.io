---
layout: page
title: About
custattr: side
---

<p></p>>
Hi! I'm Ranveer Aggarwal, a second year undergrad pursuing B.Tech. with honours in Computer Science and Engineering at IIT Bombay.
</p>
<p> A geek by default, if you want to find me, look for my laptop. And that is where I will be. Coding and Development form the core areas of my interest and I sometimes like to try my fingers on the strings of my Guitar. I like to write and blogging is another hobby of mine.</p>

